package week4.day1;

public class LaunchChromeBrowser{
	
	public void launch() {
		System.out.println("Chrome is launched");

	}
	
	public static void main(String[] args) {
		LaunchChromeBrowser browserOptions=new LaunchChromeBrowser();
		browserOptions.launch();
	}
}
