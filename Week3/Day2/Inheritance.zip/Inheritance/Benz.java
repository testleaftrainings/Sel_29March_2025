package week3.day2;

public class Benz extends Car {
	
	
	public void multipleSeater() {
		System.out.println("7 Seater");

	}
	
	

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
