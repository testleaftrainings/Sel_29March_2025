package learnreport;

public class LearnRandomNumber {

	public static void main(String[] args) {
		//double random = Math.random();
		//System.out.println(random);
		int randomNumber=(int)(Math.random()*999999999+99999999);
	}

}
