package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.edge.EdgeDriver;

import base.BaseClass;
import io.cucumber.java.en.But;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class WelcomePage extends BaseClass {
	
		
	@Then("It should navigate to the next page")
	public void verifyLogin() {
		System.out.println("Login Successful");

	}
	
	@But("It should throw error message")
	public void invalidLogin() {
		System.out.println("Login not successful");

	}
	
	@When("Click on the CRMSFA link")
   public MyHomePage clickCRMSFALink() {
		getDriver().findElement(By.linkText("CRM/SFA")).click();
       return new MyHomePage();
	}
   
   public LoginPage logout() {
	   getDriver().findElement(By.xpath("//input[@class='decorativeSubmit']")).click();
    return new LoginPage();
}

}
