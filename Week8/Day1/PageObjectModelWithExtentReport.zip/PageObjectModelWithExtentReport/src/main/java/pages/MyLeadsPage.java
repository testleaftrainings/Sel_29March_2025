package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.edge.EdgeDriver;

import base.BaseClass;
import io.cucumber.java.en.When;

public class MyLeadsPage extends BaseClass {
	
	
	@When("Click on the CreateLead link")
	public CreateLeadPage clickCreateLeadLink() {
		getDriver().findElement(By.linkText("Create Lead")).click();
         return new CreateLeadPage();
	}

}
