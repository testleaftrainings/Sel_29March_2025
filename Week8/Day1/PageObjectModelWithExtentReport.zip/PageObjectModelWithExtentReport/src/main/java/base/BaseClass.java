package base;

import java.io.File;
import java.io.IOException;
import java.time.Duration;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.edge.EdgeDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.DataProvider;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.MediaEntityBuilder;
import com.aventstack.extentreports.reporter.ExtentHtmlReporter;

import io.cucumber.testng.AbstractTestNGCucumberTests;
import utils.ReadExcel;

public class BaseClass extends AbstractTestNGCucumberTests {
	
	//public EdgeDriver driver;
	private static final ThreadLocal<EdgeDriver> edriver=new ThreadLocal<EdgeDriver>();
	public static ExtentReports extent;
	public static String testName, testDescription,authorName,categoryName;
	public static ExtentTest test;
	
	public void setDriver() {
		edriver.set(new EdgeDriver());
	}
	
   public EdgeDriver getDriver() {
		EdgeDriver edgeDriver = edriver.get();
		return edgeDriver;
	}
	
	public String filename;
	
	@BeforeSuite
	public void startReport() {
		
				ExtentHtmlReporter reporter=new ExtentHtmlReporter("./Reports/Login.html");
                extent=new ExtentReports(); 
                extent.attachReporter(reporter); 
				
	}
	
	@BeforeClass
	public void testcaseDetails() {
		test = extent.createTest(testName, testDescription);
        test.assignAuthor(authorName);
        test.assignCategory(categoryName);
	}
	
	public void reportStep(String status, String message) throws IOException {
		if (status.equals("Pass")) {
			test.pass(message, MediaEntityBuilder.createScreenCaptureFromPath(".././snaps/image"+takeSnap()+".png").build());
		}
		
		else  {
			test.fail(message, MediaEntityBuilder.createScreenCaptureFromPath("./snaps/image"+takeSnap()+".png").build());
		}

	}
	
	public int takeSnap() throws IOException {
		int randomNumber=(int)(Math.random()*999999999+99999999);    //123    234   456
		File source = getDriver().getScreenshotAs(OutputType.FILE);
		File destination=new File("./snaps/image"+randomNumber+".png");
		FileUtils.copyFile(source, destination);
        return randomNumber;
	}
	
	
	
	@AfterSuite
	public void stopReport() {
		extent.flush();
	}
	
	@BeforeMethod
	public void preConditions() {
		setDriver();
		//driver=new EdgeDriver();
		getDriver().get("http://leaftaps.com/opentaps/control/login");
		getDriver().manage().window().maximize();
		getDriver().manage().timeouts().implicitlyWait(Duration.ofSeconds(30));

	}
	@AfterMethod
   public void postConditions() {
		getDriver().close();

	}
	
	@DataProvider(name="fetchData")
	public String[][] sendData() throws IOException {
		String[][] readData = ReadExcel.readData(filename);
         return readData;
	}

}
