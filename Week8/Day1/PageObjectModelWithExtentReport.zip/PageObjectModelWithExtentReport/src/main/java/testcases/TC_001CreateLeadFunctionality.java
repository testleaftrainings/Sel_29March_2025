package testcases;

import java.io.IOException;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import base.BaseClass;
import pages.LoginPage;

public class TC_001CreateLeadFunctionality extends BaseClass {
	
	@BeforeTest
	public void setValue() {
		filename="CreateLead";
		testName="CreateLead";
		testDescription="CreateLead with multiple data";
		authorName="Vineeth";
		categoryName="Regression";
		

	}
	
	
	@Test(dataProvider="fetchData")
	public void runCreateLead(String username, String password, String cName, String fName, String lName) throws IOException {
		LoginPage lp=new LoginPage();
		lp.enterUsername(username)
		.enterPassword(password)
		.clickLoginButton()
		.clickCRMSFALink()
		.clickLeadsLink()
		.clickCreateLeadLink()
		.enterCompanyName(cName)
		.enterFirstName(fName)
		.enterLastName(lName)
		.clickCreateLeadButton()
		.verifyLead();

	}

}

//@Test  @BeforeMethod  @AfterMethod
