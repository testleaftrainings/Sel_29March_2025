package testcases;

import java.io.IOException;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import base.BaseClass;
import pages.LoginPage;

public class TC_002LoginFunction extends BaseClass {
	
	
	@BeforeTest
	public void setValue() {
		filename="Login";
		testName="Login";
		testDescription="Login with valid credentials";
		authorName="Hari";
		categoryName="Smoke";

	}
	
	
	@Test(dataProvider="fetchData")
	public void runLogin(String username, String password) throws IOException {
		LoginPage lp=new LoginPage();
		lp.enterUsername(username)
		.enterPassword(password)
		.clickLoginButton();

	}

}
