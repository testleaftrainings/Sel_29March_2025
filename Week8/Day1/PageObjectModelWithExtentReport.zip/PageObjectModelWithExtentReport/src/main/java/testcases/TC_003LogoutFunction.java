package testcases;

import java.io.IOException;

import org.testng.annotations.Test;

import base.BaseClass;
import pages.LoginPage;

public class TC_003LogoutFunction extends BaseClass {
	
	@Test
	public void runLogout(String username, String password) throws IOException {
		LoginPage lp=new LoginPage();
		lp.enterUsername(username)
		.enterPassword(password)
		.clickLoginButton()
		.logout();

	}

}
