package week1.day1;

public class SecondProgram {

	//  S/C type main and then ctrl+space
	public static void main(String[] args) {
		System.out.println("Second Program");
	}

}
