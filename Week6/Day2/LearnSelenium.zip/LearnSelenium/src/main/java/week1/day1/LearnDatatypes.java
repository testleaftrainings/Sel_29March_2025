package week1.day1;

public class LearnDatatypes {
	
public static void main(String[] args) {
	   //byte
	   byte age=30;
	   System.out.println(age);
	   
	   //short
	   short ageOfPerson=128;
	   short amount=30000;
	   
	   //int
	   int depositAmount=50000;
	   long mobileNumber=8925411170L;
	   
	   //float
	   float rateOfInterest=7.5F;
	   
	   //double
	   float rupee=1.123456789F;
	   double usd=1.123456789;
	   System.out.println(rupee);
	   System.out.println(usd);
	   
	   //boolean
	   boolean haveBreakfast=false;
	   
	   //char
	    char logo='T';
	   
	   //String
	   String name="Vineeth";
	}

}
