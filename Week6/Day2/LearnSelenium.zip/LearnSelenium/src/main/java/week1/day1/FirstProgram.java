package week1.day1;

public class FirstProgram {
   
	public static void main(String args[]) {
		System.out.println("This is my first program");
	}
	
}

 