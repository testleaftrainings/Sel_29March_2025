package week1.day2;

public class LearnForLoop {

	public static void main(String[] args) {
	    // To print the numbers from 1 to 5
		//Start number=1  Ending number=5
		
		for(int i=2;i<5;i++) {
			System.out.println(i); 
		}
		System.out.println("-------------");
		
		//To print the numbers from 5 to 1
		//use reverse for loop       
		//Starting point=5  Ending Point=1
		
		for(int i=5;i>=1;i--) {
			System.out.println(i);
		}
		
	}

}
