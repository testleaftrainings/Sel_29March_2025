package week3.day2;

public class Vehicle {
	
	public void applyBrake() {
		System.out.println("Brake applies");

	}
	
}
