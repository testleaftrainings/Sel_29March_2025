package week2.day1;

import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;

public class LaunchBrowser {
	
	public static void main(String[] args) {
		
		//EdgeDriver driver=new EdgeDriver();
		
		
		//Launch the browser - ChromeBrowser
		ChromeDriver driver=new ChromeDriver();
		
		//Load the URL (get)
		driver.get("https://www.facebook.com/");
		
		//Maximize the browser
		//driver.manage().window().maximize();
		
	}

}
