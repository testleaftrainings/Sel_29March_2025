package week2.day1;

public class LearnMethods {
	//Methods
	
	//Normal method - To perform an action
	public void method1() {
		
	}
	
	
	
	
	//Main method - To execute the program
	public static void main(String[] args) {
		
	}
	

}
