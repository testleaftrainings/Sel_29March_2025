package week2.day1;

public class Iphone {

	public static void main(String[] args) {
		Mobile mobOptions=new Mobile();
		mobOptions.sendSms();
		mobOptions.makeCall();

	}

}
