package week1.day2;

public class LearnIfCondition {

	public static void main(String[] args) {
		int a=7;
		int b=7;
		if(a>b) {
			System.out.println("b is less than a");
		}
		
		else {
			System.out.println("a is less than b");
		}

	}

}
